"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_scrollView.Cnds =
	{
	};
}
